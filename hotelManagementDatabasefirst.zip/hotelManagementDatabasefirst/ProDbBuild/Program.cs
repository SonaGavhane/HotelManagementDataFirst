﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProDbBuild
{
    class Program
    {
        public static City getCityData()
        {
            City c = new City();
            c.idCity = Convert.ToInt32(Console.ReadLine());
            c.cityName = Console.ReadLine();
            c.idCountry = Convert.ToInt32(Console.ReadLine());
            return c;
        }
        public static Address getAddressData()
        {
            Address a = new Address();
            a.idAddress = Convert.ToInt32(Console.ReadLine());
            a.address1 = Console.ReadLine();
            a.address2 = Console.ReadLine();
            a.address3 = Console.ReadLine();
            a.postalCode = Console.ReadLine();
            a.idCity = Convert.ToInt32(Console.ReadLine());
            return a;
        }
        public static Building GetBuildingData()
        {
            Building b = new Building();
            b.idBuilding = Convert.ToInt32(Console.ReadLine());
            b.floorNum = Convert.ToInt32(Console.ReadLine());
            b.latitude = Convert.ToInt32(Console.ReadLine());
            b.longitude = Convert.ToInt32(Console.ReadLine());
            b.idAddress = Convert.ToInt32(Console.ReadLine());
            return b;
        }

        public static Room GetRoomData()
        {
            Room r = new Room();
            r.idRoom = Convert.ToInt32(Console.ReadLine());
            r.nameRoom = Console.ReadLine();
            r.descRoom = Console.ReadLine();
            r.capacityRoom= Convert.ToInt32(Console.ReadLine());
            r.enable= Convert.ToInt32(Console.ReadLine());
            r.note = Console.ReadLine();
            r.smart= Convert.ToInt32(Console.ReadLine());
            r.idBuilding= Convert.ToInt32(Console.ReadLine());
            return r;
        }

        public static void display(City c)
        {
            Console.WriteLine("{0}\t{1}\t{2}\t{3}", c.idCity, c.cityName, c.idCountry, c.Country.countryName);
        }
        public static void display(Address a)
        {
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}", a.idAddress,a.address1, a.address2,a.address3,a.postalCode,a.idCity, a.City.cityName);
        }
        public static void display(Building b)
        {
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t", b.idBuilding, b.floorNum, b.latitude, b.longitude, b.idAddress, b.Address.address1, b.Address.postalCode);
        }
        public static void display(Room r)
        {
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{7}\t{8}\t{9}\t",r.idRoom,r.nameRoom,r.descRoom,r.capacityRoom,r.enable,r.note,r.smart,r.idBuilding,r.Building.floorNum,r.Building.Address.address1);
        }
        static void Main(string[] args)
        {
            ProjectBuildManageEntities db = new ProjectBuildManageEntities();
            int choice,id;
            City c = new City();
            Address a = new Address();
            Building b = new Building();
            Room r = new Room();
            do
            {
                Console.WriteLine("1.Insert on City:");
                Console.WriteLine("2.Insert on Address");
                Console.WriteLine("3.insert on Building");
                Console.WriteLine("4.insert on Room");
                Console.WriteLine("5.display city info");
                Console.WriteLine("6.display Adress info");
                Console.WriteLine("7.display Building info");
                Console.WriteLine("8.display room info:");
                Console.WriteLine("9.update City info");
                Console.WriteLine("10.update Address info:");
                Console.WriteLine("11.update Building info:");
                Console.WriteLine("12.update Room info:");
                Console.WriteLine("13.delete from City ");
                Console.WriteLine("14.delete from Address :");
                Console.WriteLine("15.delete from Building :");
                Console.WriteLine("16.delete from Room :");

                Console.WriteLine("17.Exit");
                Console.WriteLine("enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                Console.WriteLine("Enter city id,city name,country id:");
                c = getCityData();
                db.Cities.Add(c);
                db.SaveChanges();
                        break;
                    case 2:Console.WriteLine("enter Address id,Address1,Address2,Address3,PostalCode,city id");
                        a = getAddressData();
                        db.Addresses.Add(a);
                        db.SaveChanges();
                        break;
                    case 3:Console.WriteLine("Enter building id,floor num,latitude,logitude,Address id");
                        b = GetBuildingData();
                        db.Buildings.Add(b);
                        db.SaveChanges();
                        break;
                    case 4:Console.WriteLine("enter Room id,name,description,capacity,enable,note,smart,building id:");
                        r = GetRoomData();
                        db.Rooms.Add(r);
                        db.SaveChanges();
                        break;

                    case 5:
                Console.WriteLine("CityId\tCityNAME\tCountryId\tCountryName\t");
                Console.WriteLine("----------------------------------------------");
                foreach (City c1 in db.Cities)
                {
                    display(c1);
                }
               break;
                   case 6:Console.WriteLine("AddressId\t Address1\t Address2\t Address3\t PostalCode\t city Id\t City name\t");
                        Console.WriteLine("----------------------------------------");
                        foreach (Address a1 in db.Addresses)
                        {
                            display(a1);
                        }
                        break;
                    case 7:Console.WriteLine("Building Id\t Floor num\t latitude\t logitude\t address id\t address1\t postalcode\t");
                        Console.WriteLine("----------------------------------------------");
                        foreach (Building b1 in db.Buildings)
                        {
                            display(b1);
                        }
                        break;
                    case 8:
                        Console.WriteLine("Room Id\t name\t description\t Capacity\t Enable\t Note\t Smart\t Building id\t floor no\t address\t");
                        Console.WriteLine("----------------------------------------------");
                        foreach (Room r1 in db.Rooms)
                        {
                            display(r1);
                        }
                        break;
                    case 9:
                        Console.WriteLine("UPDATE RECORD");
                        Console.WriteLine("Enter the City id");
                        id = Convert.ToInt32(Console.ReadLine());
                        c = db.Cities.Find(id);
                        if (c == null)
                         Console.WriteLine("ID NOT FOUND");
                        else
                        {
                            Console.WriteLine("ENTER city name\tCountry id\t ");
                            c.cityName = Console.ReadLine();
                            c.idCountry = Convert.ToInt32(Console.ReadLine());
                            
                            db.SaveChanges();
                        }
                        break;
                    case 10:
                        Console.WriteLine("UPDATE RECORD");
                        Console.WriteLine("Enter the Address id");
                        id = Convert.ToInt32(Console.ReadLine());
                        a = db.Addresses.Find(id);
                        if (a == null)
                            Console.WriteLine("ID NOT FOUND");
                        else
                        {
                            Console.WriteLine("ENTER address\t postal Code\t ");
                            a.address1 = Console.ReadLine();
                            a.postalCode = Console.ReadLine();

                            db.SaveChanges();
                        }
                        break;
                    case 11:
                        Console.WriteLine("UPDATE RECORD");
                        Console.WriteLine("Enter the Building id");
                        id = Convert.ToInt32(Console.ReadLine());
                        b = db.Buildings.Find(id);
                        if (b == null)
                            Console.WriteLine("ID NOT FOUND");
                        else
                        {
                            Console.WriteLine("ENTER floor num\t address id\t ");
                            b.floorNum = Convert.ToInt32(Console.ReadLine());
                            b.idAddress = Convert.ToInt32(Console.ReadLine());

                            db.SaveChanges();
                        }
                        break;
                    case 12:
                        Console.WriteLine("UPDATE RECORD");
                        Console.WriteLine("Enter the Room id");
                        id = Convert.ToInt32(Console.ReadLine());
                        r= db.Rooms.Find(id);
                        if (r == null)
                            Console.WriteLine("ID NOT FOUND");
                        else
                        {
                            Console.WriteLine("ENTER room name\t  Capacity\t ");
                            r.nameRoom = Console.ReadLine();
                            r.capacityRoom = Convert.ToInt32(Console.ReadLine());

                            db.SaveChanges();
                        }
                        break;
                    case 13: Console.WriteLine("Delete RECORD");
                        Console.WriteLine("Enter the City id");
                        id = Convert.ToInt32(Console.ReadLine());
                        c = db.Cities.Find(id);
                        if (c == null)
                            Console.WriteLine("ID NOT FOUND");
                        else
                        {
                            db.Cities.Remove(c);
                            db.SaveChanges();
                        }
                        break;
                    case 14:Console.WriteLine("Delete record");
                        Console.WriteLine("enter Address id");
                        id = Convert.ToInt32(Console.ReadLine());
                        a = db.Addresses.Find(id);
                        if (a == null)
                            Console.WriteLine("id not found");
                        else
                        {
                            db.Addresses.Remove(a);
                            db.SaveChanges();
                        }
                        break;
                    case 15:
                        Console.WriteLine("Delete record");
                        Console.WriteLine("enter Building id");
                        id = Convert.ToInt32(Console.ReadLine());
                        b = db.Buildings.Find(id);
                        if (b == null)
                            Console.WriteLine("id not found");
                        else
                        {
                            db.Buildings.Remove(b);
                            db.SaveChanges();
                        }
                        break;
                    case 16:
                        Console.WriteLine("Delete record");
                        Console.WriteLine("enter Room id");
                        id = Convert.ToInt32(Console.ReadLine());
                        r = db.Rooms.Find(id);
                        if (r == null)
                            Console.WriteLine("id not found");
                        else
                        {
                            db.Rooms.Remove(r);
                            db.SaveChanges();
                        }
                        break;
                    case 17:break;
                    default:Console.WriteLine("invalid choice!!!!!");
                        break;
               }
            } while (choice!= 17);

        }
    }
}
